# deploy
kubectl apply -f /vagrant/guestbook/

# check
kubectl get service frontend